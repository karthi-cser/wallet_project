import { Component, OnInit , Inject,ViewChild} from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import { JobService } from '../../../job.service';
import { Question } from 'src/app/models/question.model';
import { CenterList } from 'src/app/models/center-list.model';
import { TestList } from 'src/app/models/test-list.model';



import {UpdateComponent} from "../update/update.component";

//import { ModalController } from '@angular/angular';
//import { UpdateComponent } from './job/question/update/update.component';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';


import { NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';




@Component({
  selector: 'app-lists',
  templateUrl: './lists.component.html',
  styleUrls: ['./lists.component.css']
   

})
export class ListsComponent implements OnInit {
questions : Question[];
test : TestList[];

center : CenterList[];
 closeResult: string;
 public Editor = ClassicEditor;
  qus: Question; 
  editForm: FormGroup;
   addForm: FormGroup;
  page;
  title: string;
  loading:any;
QuestionN:any;
testCount :any;


    images1 = [944, 1011, 984].map((n) => `https://picsum.photos/id/${n}/900/500`);

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService,private modalService: NgbModal) { 
  
  }
 
addForm: FormGroup;
  ngOnInit() {
this.loading=true;
this.testCount=1;

    let cid = window.localStorage.getItem("testId");
  //alert(cid);
     this.jobService.TestById(+cid)
      .subscribe( data => {
      
        this.test = data.result ; 
       // console.log(this.test.name);
      });



let testId = window.localStorage.getItem("testId");
 // alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
        this.questions = data.result ;
      this.testCount= this.questions.length;
       console.log(this.testCount);

this.loading=false;

      });


  }
 
 public onReady( editor ) {
        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
    }
  

  open(content) {

  this.addForm = this.formBuilder.group({
      id: [],
      currency: ['', Validators.required], 
      
      to: ['', Validators.required], 
      amount: ['', Validators.required], 
     
      amount1: [''],
      description: ['1', Validators.required],
       network_fee: ['4', Validators.required], 
       
      

     
    });


    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason1(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }




  open2(content1) {


  this.addForm = this.formBuilder.group({
      id: [],
      currency: ['', Validators.required], 
      
      receive_to: ['', Validators.required], 
      address: ['', Validators.required], 
     
     
       
      

     
    });

    this.modalService.open(content1, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason2(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  open1(q:Question,content): void  {
  console.log(q);
  //window.localStorage.removeItem("editQuestionqId");
 //   window.localStorage.setItem("editQuestionqId", q.qid.toString());


  window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());


    let editQuestionId = window.localStorage.getItem("editQuestionId");

    
    if(!editQuestionId) {
      alert("Invalid action.")
      this.router.navigate(['listquestion']);
      return;
    }
    this.editForm = this.formBuilder.group({
      id: [''], qid: [''], test_id: [''], a1: [''],   a2: [''],   a3: [''],   a4: [''],right_answer: [''], 
      question: ['', Validators.required]  ,

    });
    this.jobService.getQuestionById(+editQuestionId)
      .subscribe( data => {
        this.editForm.setValue(data.result);
      });
     // alert(q.id.toString());
   
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {

      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {

    console.log(this.editForm.value);
    this.jobService.updateTest(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Test updated successfully.');
            //this.router.navigate(['test-list']);

          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });


    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }





  }



  editQuestion(q: Question): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
     this.router.navigate(['job/question/updatequestion']);
  };





  

sendtostatus(editQuestionId1): void {
alert(editQuestionId1);
     this.jobService.testStatus(+editQuestionId1)
.subscribe( data => {
      
       // this.test = data.result ;

     // console.log("msg",data.Message);
     // console.log("msg1", this.test.Messgae);
       if(data.Message==0){
          alert("Question updated succesfully");
     this.jobService.testdraft()
          .subscribe( data => {
          
            this.test = data.result ;
       // console.log( "ms1",this.test);
        this.router.navigate(['job/testdraft']);
             
           });
       }
if(data.Message==1){

alert("Please  updated Your Questions")

  
}


      });

      



  }; 

 onSubmit() {



    this.jobService.send_payment(this.addForm.value)
      .subscribe( data => {
      alert("Test added successfully"+data.result.id);
console.log(data);
 
      window.localStorage.setItem("testId", data.result.id);
        this.router.navigate(['job/question/listquestion']);
      });
  }


 onSubmit1() {



    this.jobService.receive_payment(this.addForm.value)
      .subscribe( data => {
      alert("Test added successfully"+data.result.id);
console.log(data);
 
      window.localStorage.setItem("testId", data.result.id);
        this.router.navigate(['job/question/listquestion']);
      });
  }
}
