import { Component, OnInit , Inject} from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";

import { JobService } from '../../../job.service';
import { Question } from 'src/app/models/question.model';
 
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
//import MathType from '@wiris/mathtype-ckeditor5';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})


export class UpdateComponent implements OnInit {

 
   public Editor = ClassicEditor;
  qus: Question; 
  editForm: FormGroup;
  questions : Question[];
  data;
  loading:any;
QuestionN:any;
qId:any;

testCount :any;
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService ) { }

  //qId:any;



  
 public onReady( editor ) {
        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
    }
	



  ngOnInit() {



this.loading=true;

    let editQuestionId = window.localStorage.getItem("editQuestionId");

    this.qId=parseInt(editQuestionId);


    if(!editQuestionId) {
      alert("Invalid action.")
      this.router.navigate(['listquestion']);
      return;
    }


    this.editForm = this.formBuilder.group({
      id: [''], qid: [''], test_id: [''], a1: [''],   a2: [''],   a3: [''],   a4: [''],right_answer: [''], solution: [''], created_at: [''], updated_at:[''],shownext:[''],showprevious:[''],qe:[''],qs:[''],
      question: ['', Validators.required]  
    });


    this.jobService.getQuestionById(+editQuestionId)
      .subscribe( data => {
        this.editForm.setValue(data);

this.loading=false;
      

      });
  }

  onSubmit() {
	  console.log(this.editForm.value);
    this.jobService.updateQuestion(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Question updated successfully.');
            this.router.navigate(['job/question/listquestion']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }



next(){


let editQuestionId = window.localStorage.getItem("editQuestionId");

 this.qId=parseInt(editQuestionId);

this.qId=this.qId+1;

 

this.jobService.getQuestionById(this.qId)
      .subscribe( data => {
        this.editForm.setValue(data);
      });
    this.jobService.updateQuestion(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => { 

window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId",this.qId);

          if(data.status === 200) {
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });

}


previous(){


this.qId=this.qId-1;
this.jobService.getQuestionById(this.qId)
      .subscribe( data => {
        this.editForm.setValue(data);
      });

      

}


}


