import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './authentication/login/login.component';
import { RegisterComponent } from './authentication/register/register.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DropdownDirective } from './component/shared/naviagtion/dropdown.directive';
import { CollapseDirective } from './component/shared/naviagtion/collapse.directive';

import { AppRoutingModule } from './app-routing.module';
import { AuthService } from './authentication/auth.service';
import { ToastrModule  } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { JwtInterceptorService } from './jwt-interceptor.service';
import { NaviagtionComponent } from './component/shared/naviagtion/naviagtion.component';
import { FooterComponent } from './component/shared/footer/footer.component';

import { DetailsComponent } from './component/job/details/details.component';
import { AllComponent } from './component/job/all/all.component';
import { CreateComponent } from './component/job/create/create.component';
import { CategoryComponent } from './component/job/category/category.component';
import { CategoryListComponent } from './component/job/category-list/category-list.component';
import { CategoryUpdateComponent } from './component/job/category-update/category-update.component';
import { TestComponent } from './component/job/test/test.component';
import { CenterComponent } from './component/job/center/center.component';
import { JobService } from './component/job.service';


import { CenterListComponent } from './component/job/center-list/center-list.component';
import { TestListComponent } from './component/job/test-list/test-list.component';
import { CenterUpdateComponent } from './component/job/center-update/center-update.component';
import { TestUpdateComponent } from './component/job/test-update/test-update.component';
import { StudentComponent } from './component/job/student/student.component';

import { GetcenterComponent } from './component/job/getcenter/getcenter.component';
import { GettestComponent } from './component/job/gettest/gettest.component';
import { GetquestionComponent } from './component/job/getquestion/getquestion.component';


import { ListUserComponent } from './component/job/user/list-user/list-user.component';

import { AddUserComponent } from './component/job/user/add-user/add-user.component';
import { EditUserComponent } from './component/job/user/edit-user/edit-user.component';

import { ListsComponent } from './component/job/question/lists/lists.component';


import { UpdateComponent } from './component/job/question/update/update.component';

 import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
 import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { TestdraftComponent } from './component/job/testdraft/testdraft.component';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    NaviagtionComponent,
    DropdownDirective,
    CollapseDirective,
    FooterComponent,
  
    DetailsComponent,
    AllComponent,
    CreateComponent,
    CategoryComponent,
   
    CategoryListComponent,
    CenterComponent,
    CategoryUpdateComponent,
    TestComponent,
    CenterListComponent,
    TestListComponent,
    CenterUpdateComponent,
    TestUpdateComponent,
    StudentComponent,
    GetcenterComponent,
    GettestComponent,
    GetquestionComponent,
    ListUserComponent,
    AddUserComponent,
    EditUserComponent,
    ListsComponent,
   
    UpdateComponent,
   
    TestdraftComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ToastrModule,
    CKEditorModule,NgbModule
  ],
  providers: [
    AuthService,
    JobService,
    {provide: HTTP_INTERCEPTORS, useClass: JwtInterceptorService, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
