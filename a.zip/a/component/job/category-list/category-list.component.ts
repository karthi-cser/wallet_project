import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import { JobService } from '../../job.service';

import { CategoryList } from 'src/app/models/category-list';
import { Location } from '@angular/common';
@Component({
  selector: 'app-category-list',
  templateUrl: './category-list.component.html',
  styleUrls: ['./category-list.component.css']
})
export class CategoryListComponent implements OnInit {
category : CategoryList[];


  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService ,private location: Location) { }

  

  ngOnInit() {
     this.jobService.getCategory()
      .subscribe( data => {
		  
      this.category = data.result ;
		console.log( data);


    


		   
      });


  }

   editQuestion(q:CategoryList): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
     this.router.navigate(['category-update']);
   alert(q.id.toString());
  };




addCategory(): void {
   this.router.navigate(['/job/category'])
  }; 


sendto(q:CategoryList): void {
window.localStorage.removeItem("categoryId");
window.localStorage.setItem("categoryId", q.id.toString());
   this.router.navigate(['job/getcenter']);
  }; 


  sendtostatus(q:CategoryList): void {
  window.localStorage.removeItem("categoryId");
  window.localStorage.setItem("categoryId", q.id.toString());


  
   alert( q.id.toString());
    this.jobService.categoryStatus(+q.id.toString())
      .subscribe( data => {
      
       this.category = data.result ;
   console.log( this.category);
         
      });



  }; 
}
