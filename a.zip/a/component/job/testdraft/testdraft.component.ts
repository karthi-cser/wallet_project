import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";

import { JobService } from '../../job.service';

import { TestList } from 'src/app/models/test-list.model';

@Component({
  selector: 'app-testdraft',
  templateUrl: './testdraft.component.html',
  styleUrls: ['./testdraft.component.css']
})
export class TestdraftComponent implements OnInit {
test : TestList[];
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

  ngOnInit() {


    let cid = window.localStorage.getItem("cid");
  //alert("cid",cid);
     this.jobService.testdraft(+cid)
      .subscribe( data => {
      
        this.test = data.result ;
    console.log( this.test);
   // window.localStorage.removeItem("");
  // alert(this.test.name);
    //window.localStorage.setItem("test_name",this.test.name );
       
      });

  }

 editQuestion(q:TestList): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
    window.localStorage.removeItem("test_name");
    //window.localStorage.setItem("test_name", q.name);
     this.router.navigate(['job/test-update']);
   alert(q.id.toString());
  };

   addTest(): void {
    this.router.navigate(['/job/test'])
  }; 

  sendto1(): void {
   this.router.navigate(['job/question/listquestion']);
  }; 

sendto(q:TestList): void {
  window.localStorage.removeItem("testId");
  window.localStorage.setItem("testId", q.id.toString());
   this.router.navigate(['job/question/listquestion']);
  }; 

  sendtostatus(q:TestList): void {

    window.localStorage.removeItem("testId");
  window.localStorage.setItem("testId", q.id.toString());
    alert( q.id.toString());
     this.jobService.testStatus(+q.id.toString())
      .subscribe( data => {
      
        this.test = data.result ;
    console.log( this.test);
         
      });



  }; 

}
