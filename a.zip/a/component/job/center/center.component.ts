import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import { JobService } from '../../job.service';
import { CategoryList } from 'src/app/models/category-list';

@Component({
  selector: 'app-center',
  templateUrl: './center.component.html',
  styleUrls: ['./center.component.css']
})
export class CenterComponent implements OnInit {

category : CategoryList[];
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

  addForm: FormGroup;

  ngOnInit() {
  this.addForm = this.formBuilder.group({
      id: [],
      name: ['', Validators.required], 
       username: ['', Validators.required],
        password: ['', Validators.required],
         mobile_no: ['', Validators.required],
      about: ['', Validators.required],
      category_id:['',Validators.required],
       fileToUpload:['',Validators.required]
     
     
    });


     this.jobService.getCategory()
      .subscribe( data => {
		  
        this.category = data.result ;
		console.log( this.category);
		   
      });
  }

  onSubmit() {
    this.jobService.createCenter(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['job/center-list']);
      });
  }

}
