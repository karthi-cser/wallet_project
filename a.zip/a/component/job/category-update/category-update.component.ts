import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import {CategoryUpdate} from "src/app/models/category-update.model";
import { JobService } from '../../job.service';




@Component({
  selector: 'app-category-update',
  templateUrl: './category-update.component.html',
  styleUrls: ['./category-update.component.css']
})
export class CategoryUpdateComponent implements OnInit {

  category: CategoryUpdate; 
  editForm: FormGroup;

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService ) { }

   public onReady( editor ) {
        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
    }

  ngOnInit() {




    let editQuestionId = window.localStorage.getItem("editQuestionId");
    if(!editQuestionId) {
      alert("Invalid action.")
      this.router.navigate(['job/category-list']);
      return;
    }
    alert("dd");
    this.editForm = this.formBuilder.group({
      id: [''],   description: [''], 
      c_name: ['', Validators.required]  
    });
    this.jobService.getCategoryById(+editQuestionId)
      .subscribe( data => {
        this.editForm.setValue(data.result);
      });
  }


onSubmit() {
	  console.log(this.editForm.value);
    this.jobService.updateCategory(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Category updated successfully.');
            this.router.navigate(['job/category-list']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }
}
