import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";

import { JobService } from '../../job.service';

import { Student } from 'src/app/models/student.model';


@Component({
  selector: 'app-student',
  templateUrl: './student.component.html',
  styleUrls: ['./student.component.css']
})
export class StudentComponent implements OnInit {

student : Student[];

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

 
 addForm: FormGroup;

  ngOnInit() {
  this.addForm = this.formBuilder.group({
  
      studentdetails: ['', Validators.required]
     
    });


  }

  onSubmit() {
    this.jobService.createStudent(this.addForm.value)
      .subscribe( data => {
       alert("Student Details Added Successfully");
        this.router.navigate(['job/user/list-user']);
      });
  }
}
