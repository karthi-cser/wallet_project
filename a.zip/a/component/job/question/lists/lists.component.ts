import { Component, OnInit , Inject,ViewChild} from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";
import { JobService } from '../../../job.service';
import { Question } from 'src/app/models/question.model';
import { CenterList } from 'src/app/models/center-list.model';
import { TestList } from 'src/app/models/test-list.model';



import {UpdateComponent} from "../update/update.component";

//import { ModalController } from '@angular/angular';
//import { UpdateComponent } from './job/question/update/update.component';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';


import { NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';




@Component({
  selector: 'app-lists',
  templateUrl: './lists.component.html',
  styleUrls: ['./lists.component.css']
   

})
export class ListsComponent implements OnInit {
questions : Question[];
test : TestList[];
center : CenterList[];
 closeResult: string;
 public Editor = ClassicEditor;
  qus: Question; 
  editForm: FormGroup;
  page;
  title: string;


    images1 = [944, 1011, 984].map((n) => `https://picsum.photos/id/${n}/900/500`);





  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService,private modalService: NgbModal) { 
  
  }
 
addForm: FormGroup;
  ngOnInit() {




    let cid = window.localStorage.getItem("testId");
  alert(cid);
     this.jobService.TestById(+cid)
      .subscribe( data => {
      
        this.test = data.result ;
   // console.log( "test",this.test.name);
//alert("test id",this.test.id);
  
    
       
      });



    //let test_name= window.localStorage.getItem("test_name");
    //alert(test_name);
let testId = window.localStorage.getItem("testId");
  alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
      alert(testId);
        this.questions = data.result ;
    console.log( this.questions);
       
      });


	  


  }



 
 public onReady( editor ) {
        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
    }
  





images = [62, 83, 466, 965, 982, 1043, 738].map((n) => `https://picsum.photos/id/${n}/900/500`);

  paused = false;
  unpauseOnArrow = false;
  pauseOnIndicator = false;
  pauseOnHover = true;

  @ViewChild('carousel', {static : true}) carousel: NgbCarousel;

 togglePaused() {
     
      this.carousel.next();
    
  }



  onSlide(slideEvent: NgbSlideEvent) {
    if (this.unpauseOnArrow && slideEvent.paused &&
      (slideEvent.source === NgbSlideEventSource.ARROW_LEFT || slideEvent.source === NgbSlideEventSource.ARROW_RIGHT)) {
      this.togglePaused();
    }
    if (this.pauseOnIndicator && !slideEvent.paused && slideEvent.source === NgbSlideEventSource.INDICATOR) {
      this.togglePaused();
    }
  }






  open(content) {

    
    let editQuestionId = window.localStorage.getItem("testId");
alert(editQuestionId);

    if(!editQuestionId) {
      alert("Invalid action.")
      //this.router.navigate(['job/test-list']);
      return; 
    }

  alert(editQuestionId);
    this.editForm = this.formBuilder.group({
      name: ['', Validators.required],id: [''], center_id: [''], duration: [''], status: [''], question: [''],  marks: [''],  description: [''], created_by: [''], date: [''],  percentage: [''], negativemarks: ['']
       
    });


    this.jobService.getTestById(+editQuestionId)
      .subscribe( data => {
      alert("ssss");

      console.log(data);


        this.editForm.setValue(data.result);



      });


    
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason1(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }




  open2(content1) {

  
    let editQuestionId = window.localStorage.getItem("testId");
alert(editQuestionId);

    if(!editQuestionId) {
      alert("Invalid action.")
      //this.router.navigate(['job/test-list']);
      return; 
    }

  alert(editQuestionId);
    this.editForm = this.formBuilder.group({
        name: ['', Validators.required],id: [''], center_id: [''], duration: [''], status: [''], question: [''],  marks: [''],  description: [''], created_by: [''], date: [''],  percentage: [''], negativemarks: ['']
       
    });


    this.jobService.getTestById(+editQuestionId)
      .subscribe( data => {
      alert("ssss");

      console.log(data);

        this.editForm.setValue(data.result);



      });

    this.modalService.open(content1, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason2(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

  open1(q:Question,content): void  {
  console.log(q);
  window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
    let editQuestionId = window.localStorage.getItem("editQuestionId");
    if(!editQuestionId) {
      alert("Invalid action.")
      this.router.navigate(['listquestion']);
      return;
    }
    this.editForm = this.formBuilder.group({
      id: [''], qid: [''], test_id: [''], a1: [''],   a2: [''],   a3: [''],   a4: [''],answer: [''], 
      question: ['', Validators.required]  ,

    });
    this.jobService.getQuestionById(+editQuestionId)
      .subscribe( data => {
        this.editForm.setValue(data.result);
      });
      alert(q.id.toString());
   
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {

      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }



  editQuestion(q: Question): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
     this.router.navigate(['job/question/updatequestion']);
   alert(q.id.toString());
  };




onSubmit() {
 


    console.log(this.editForm.value);
    this.jobService.updateQuestion(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Question updated successfully.');
            this.router.navigate(['job/question/listquestion']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }
   
 
  onSubmit1() {
   console.log(this.editForm.value);
    this.jobService.updateTest(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Test Instructions updated successfully.');
            this.router.navigate(['job/question/listquestion']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });

    
  }
  
  onSubmit3() {
    console.log(this.editForm.value);
    this.jobService.updateTest(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Test updated successfully.');
            //this.router.navigate(['test-list']);

          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }




}
