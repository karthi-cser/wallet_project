export class CategoryList{

  id: number;

}
