export class TestUpdate{

  id: number;

}
