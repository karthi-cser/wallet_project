export class CenterUpdate{

  id: number;

}
