export class CategoryUpdate{

  id: number;

}
