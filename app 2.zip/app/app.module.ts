import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './authentication/login/login.component';
import { RegisterComponent } from './authentication/register/register.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { DropdownDirective } from './component/shared/naviagtion/dropdown.directive';
import { CollapseDirective } from './component/shared/naviagtion/collapse.directive';

import { AppRoutingModule } from './app-routing.module';
import { AuthService } from './authentication/auth.service';
import { ToastrModule  } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { JwtInterceptorService } from './jwt-interceptor.service';
import { NaviagtionComponent } from './component/shared/naviagtion/naviagtion.component';
import { FooterComponent } from './component/shared/footer/footer.component';



import { MatSliderModule } from '@angular/material/slider';

import { TestComponent } from './component/job/test/test.component';
import { CenterComponent } from './component/job/center/center.component';
import { JobService } from './component/job.service';



import { TestListComponent } from './component/job/test-list/test-list.component';
import { CenterUpdateComponent } from './component/job/center-update/center-update.component';


import { ListUserComponent } from './component/job/user/list-user/list-user.component';



 import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
 import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { TestdraftComponent } from './component/job/testdraft/testdraft.component';

import { NgxSpinnerModule } from "ngx-spinner"; 

import {MatSnackBar} from '@angular/material/snack-bar';

import { MatTableModule } from '@angular/material';
import { KycDocumentComponent } from './component/job/kyc-document/kyc-document.component' 




import { MatToolbarModule, MatIconModule, MatSidenavModule, MatListModule, MatButtonModule } from  '@angular/material';




@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginComponent,
    RegisterComponent,
    NaviagtionComponent,
    DropdownDirective,
    CollapseDirective,
    FooterComponent,
    
    CenterComponent,

    TestComponent,

    TestListComponent,
    CenterUpdateComponent,

    ListUserComponent,
    TestdraftComponent,
    KycDocumentComponent,
   

   
    
  
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    ToastrModule,
    CKEditorModule,NgbModule,
    NgxSpinnerModule,MatSliderModule,MatTableModule

  ],
  providers: [
    AuthService,
    JobService,
    {provide: HTTP_INTERCEPTORS, useClass: JwtInterceptorService, multi: true }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
