export class Test {

  id: number;
   message: number;
  result: any;
    Message: number;
     status: number;

}
