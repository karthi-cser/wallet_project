export class Center {

  id: number;

}
