export class TestList{

  id: number;
   

}
