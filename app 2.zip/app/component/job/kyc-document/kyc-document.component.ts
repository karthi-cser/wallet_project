import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators,NgModel} from "@angular/forms";
import {Router} from "@angular/router";
import { JobService } from '../../job.service';
import {first} from "rxjs/operators";
import { TestList } from 'src/app/models/test-list.model';
import { User } from 'src/app/models/user.model';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-kyc-document',
  templateUrl: './kyc-document.component.html',
  styleUrls: ['./kyc-document.component.css']
})
export class KycDocumentComponent implements OnInit {
   addForm: FormGroup;
   test : TestList[];
 users: User[];

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService,private modalService: NgbModal) { }

  ngOnInit() {
  }


}
