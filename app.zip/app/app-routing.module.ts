import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './authentication/login/login.component';
import { RegisterComponent } from './authentication/register/register.component';
import { CreateComponent } from './component/job/create/create.component';
import { AllComponent } from './component/job/all/all.component';

import { DetailsComponent } from './component/job/details/details.component';
import { CategoryComponent } from './component/job/category/category.component';


 import {CategoryListComponent} from "./component/job/category-list/category-list.component";
 import {CategoryUpdateComponent} from "./component/job/category-update/category-update.component";

 import {CenterComponent} from "./component/job/center/center.component";
 import {CenterListComponent} from "./component/job/center-list/center-list.component";
 import {CenterUpdateComponent} from "./component/job/center-update/center-update.component";

 import {TestComponent} from "./component/job/test/test.component";
 import {TestListComponent} from "./component/job/test-list/test-list.component";
 import {TestUpdateComponent} from "./component/job/test-update/test-update.component";

import {StudentComponent} from "./component/job/student/student.component";
 
import { AuthGuard } from './authentication/guards/auth.guard';

import {GettestComponent} from "./component/job/gettest/gettest.component";
 import {GetcenterComponent} from "./component/job/getcenter/getcenter.component";
 import {GetquestionComponent} from "./component/job/getquestion/getquestion.component";
 import {TestdraftComponent} from "./component/job/testdraft/testdraft.component";


 import {AddUserComponent} from "./component/job/user/add-user/add-user.component";
import {ListUserComponent} from "./component/job/user/list-user/list-user.component";
import {EditUserComponent} from "./component/job/user/edit-user/edit-user.component";
import {ListsComponent} from "./component/job/question/lists/lists.component";

import {UpdateComponent} from "./component/job/question/update/update.component";
import { NewUserComponent } from './component/job/user/new-user/new-user.component';


const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'home' },
  { path: 'home', component: HomeComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'job/create', component: CreateComponent,canActivate: [AuthGuard] },
  { path: 'job/all', component: AllComponent,canActivate: [AuthGuard] },
 
  { path: 'job/details/:id', component: DetailsComponent,canActivate: [AuthGuard] },
  { path: 'job/category', component: CategoryComponent, canActivate: [AuthGuard] },
  { path: 'job/category-list', component: CategoryListComponent, canActivate: [AuthGuard]},
  { path: 'job/center-list', component: CenterListComponent, canActivate: [AuthGuard]},
  { path: 'job/test-list', component: TestListComponent, canActivate: [AuthGuard]},
  { path: 'job/center', component: CenterComponent, canActivate: [AuthGuard]},
  { path: 'job/category-update', component: CategoryUpdateComponent, canActivate: [AuthGuard]},
   { path: 'job/test-update', component: TestUpdateComponent, canActivate: [AuthGuard]},
    { path: 'job/center-update', component: CenterUpdateComponent, canActivate: [AuthGuard]},
     { path: 'job/student', component: StudentComponent, canActivate: [AuthGuard]},
     { path: 'job/test', component: TestComponent, canActivate: [AuthGuard]},
  
  { path: 'job/gettest', component: GettestComponent , canActivate: [AuthGuard]},
   { path: 'job/testdraft', component: TestdraftComponent , canActivate: [AuthGuard]},
{ path: 'job/getcenter', component: GetcenterComponent , canActivate: [AuthGuard]},
{ path: 'job/getquestion', component: GetquestionComponent , canActivate: [AuthGuard]},
{ path: 'job/user/add-user', component: AddUserComponent , canActivate: [AuthGuard]},
{ path: 'job/user/list-user', component: ListUserComponent , canActivate: [AuthGuard]},
{ path: 'job/user/edit-user', component: EditUserComponent , canActivate: [AuthGuard]},
{ path: 'job/user/new-user', component: NewUserComponent , canActivate: [AuthGuard]},
{ path: 'job/question/listquestion', component: ListsComponent, canActivate: [AuthGuard] },

{ path: 'job/question/updatequestion', component: UpdateComponent , canActivate: [AuthGuard]},


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
