export class Test {

  id: number;

}
