export class Question {

  id: number;
qid:number
}
