export class Student {

  id: number;

}
