export interface CategoryList{

 id: string;

}
