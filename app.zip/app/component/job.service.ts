import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Job } from '../models/job';
import {  CategoryList} from '../models/category-list';
import {ApiResponse} from "../models/api.response";
import {Category} from "../models/category.model";
import {Center} from "../models/center.model";
import {Test} from "../models/test.model";
import { CenterList } from '../models/center-list.model';
import { Student } from '../models/student.model';
import { User } from '../models/user.model';
import { Question } from '../models/question.model';

import { Observable } from 'rxjs';

const createcategory = "http://saksh.website/vapi/a8/tcreateCategory.php";
const allcategory = "http://saksh.website/vapi/a8/allcategory.php";
const createJob =	"http://localhost:5000/job/create";
const getAllJob = "http://saksh.website/vapi/a8/allcategory.php";
const getSingleJob = "http://localhost:5000/job/details/";
const deleteJob = "http://localhost:5000/job/delete/";
const getUserJob = "http://localhost:5000/job/user";
const getJobsByCategory = "http://localhost:5000/job/category/";
const search = "http://localhost:5000/job/search/";


@Injectable({
  providedIn: 'root'
})
export class JobService {

  constructor(private http: HttpClient) { }

  baseUrl: string = 'http://saksh.website/vapi/a8center/';

  createJob(data) {
      return this.http.post(createJob, data);
  } 

  getAllJob(): Observable<Array<Job>> {
    return this.http.get<Array<Job>>(getAllJob);
  }

  getJob(id): Observable<Job> {
    return this.http.get<Job>(getSingleJob + id);
  }

  getUserJob(): Observable<Array<Job>> {
    return this.http.get<Array<Job>>(getUserJob);
  }

  deleteJob(id) {
    return this.http.delete(deleteJob + id);
  }

  getByCategory(category): Observable<Array<Job>> {
    return this.http.get<Array<Job>>(getJobsByCategory + category);
  }

  //search
  search(query): Observable<Array<Job>> {
    return this.http.get<Array<Job>>(search + query)
  }


 createCategory(data) {
      return this.http.post(createcategory, data);
  } 



 getCategory() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'allcategory.php');
  }

 categoryStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'categoryStatus.php?id='+ id);
    
  }

  getCategoryById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getCategorybyId.php?id='+ id);
  }

  getCenter1(id:number) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getCenter.php?category_id='+ id);
  }

 getCenter() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'allcenter.php');
  }

   getTest() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'alltest.php');
  }


   getTest1(id:number) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getTest.php?center_id='+ id);
  }


    testdraft(id:number) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'alltestdraft.php?center_id='+ id);
  }

 getQuestionById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getQuestionbyId.php?id='+ id);
  }


   getQuestion1(id:number) : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'getQuestion.php?test_id='+ id);
  }


 updateCategory(category: Category): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateCategory.php?id='+ category.id, category);
  }

createCenter(center: Center): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl+'createCenter.php', center);
  }
 
 createTest(test: Test): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl+'createTest.php', test);
  }

  centerStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'centerStatus.php?id='+ id);

  }

   getCenterById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getCenterbyId.php?id='+ id);
  }

   updateCenter(center: Center): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateCenter.php?id='+ center.id, center);
  }

   createStudent(student: Student): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl+'createStudent.php', student);
  }

  testStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'testStatus.php?id='+ id);
    }


 getTestById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getTestbyId.php?center_id='+ id);
  }

TestById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'testbyid.php?test_id='+ id);
  }
    updateTest(test: Test): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateTest.php?id='+ test.id, test);
  }
   createUser(user: User): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl+'tcreateuser.php', user);
  }

  getUserById(id: number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'getUserById.php?id='+ id);
  }

   updateUser(user: User): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateUser.php?id='+ user.id, user);
  }

  deleteUser(id: number): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(this.baseUrl +'tuser.php?id='+ id);
  }

  getUsers1() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'studentlist.php');
  }

   getnewUsers() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'newstudentlist.php');
  }



   studentStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'studentStatus.php?id='+ id);
    
  }
newstudentStatus(id:number): Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl +'newstudentStatus.php?id='+ id);
    
  }

 getQuestions() : Observable<ApiResponse> {
    return this.http.get<ApiResponse>(this.baseUrl+'allquestions.php');
  }

    updateQuestion(question: Question): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(this.baseUrl +'updateQuestion.php?id='+ question.id, question);
  }
}
