import { Component, OnInit , Inject} from '@angular/core';
import {Router} from "@angular/router";
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {first} from "rxjs/operators";

import { JobService } from '../../../job.service';
import { Question } from 'src/app/models/question.model';
 
import * as ClassicEditor from '@ckeditor/ckeditor5-build-classic';
import { NgbCarousel, NgbSlideEvent, NgbSlideEventSource } from '@ng-bootstrap/ng-bootstrap';
//import MathType from '@wiris/mathtype-ckeditor5';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {

 
   public Editor = ClassicEditor;
  qus: Question; 
  editForm: FormGroup;
  questions : Question[];
  data;
  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService ) { }

  qId:any;


  images = [944, 1011, 984].map((n) => `https://picsum.photos/id/${n}/900/500`);
  
 public onReady( editor ) {
        editor.ui.getEditableElement().parentElement.insertBefore(
            editor.ui.view.toolbar.element,
            editor.ui.getEditableElement()
        );
    }
	
  ngOnInit() {


    this.jobService.getQuestions()
      .subscribe( data => {
      
        this.questions = data.result ;
    console.log( this.questions);
//alert(this.questions.qid);


       
      });

    let editQuestionId = window.localStorage.getItem("editQuestionId");

    this.qId=parseInt(editQuestionId);


    if(!editQuestionId) {
      alert("Invalid action.")
      this.router.navigate(['listquestion']);
      return;
    }
    this.editForm = this.formBuilder.group({
      id: [''], qid: [''], test_id: [''], a1: [''],   a2: [''],   a3: [''],   a4: [''],answer: [''], solution: [''], 
      question: ['', Validators.required]  
    });
    this.jobService.getQuestionById(+editQuestionId)
      .subscribe( data => {
        this.editForm.setValue(data.result);
        this.questions = data.result ;
    //console.log(this.questions);
        //  console.log("qid",this.questions.qid);
        //alert("qid",data.result.qid);
      });
  }

  onSubmit() {
	  console.log(this.editForm.value);
    this.jobService.updateQuestion(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
            alert(' Question updated successfully.');
            this.router.navigate(['job/question/listquestion']);
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });
  }



next(){


this.qId=this.qId+1;
//alert(this.qId);

this.jobService.getQuestionById(this.qId)
      .subscribe( data => {
        this.editForm.setValue(data.result);
      });

 console.log(this.editForm.value);
    this.jobService.updateQuestion(this.editForm.value)
      .pipe(first())
      .subscribe(
        data => {
          if(data.status === 200) {
           // alert(' Question updated successfully.');
            //this.router.navigate(['job/question/listquestion']);
            
          }else {
            alert(data.message);
          }
        },
        error => {
          alert(error);
        });

}


previous(){


this.qId=this.qId-1;
//alert(this.qId);

this.jobService.getQuestionById(this.qId)
      .subscribe( data => {
        this.editForm.setValue(data.result);
      });

      

}

nssssext(q){
alert(q);

this.qId=this.qId+1;
alert(this.qId);
/*

    let editQuestionId = q;
    if(!editQuestionId) {
      alert("Invalid action.")                            
      this.router.navigate(['listquestion']);
      return;
    }
    this.editForm = this.formBuilder.group({
      id: [''],  a1: [''],   a2: [''],   a3: [''],   a4: [''],answer: [''], 
      question: ['', Validators.required]  

    });
    alert(editQuestionId);
    this.jobService.getQuestionById(+editQuestionId)
      .subscribe( data => {
        this.editForm.setValue(data.result);

      });
  */

}

}
