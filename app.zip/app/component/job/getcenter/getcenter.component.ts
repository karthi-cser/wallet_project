import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";



import { JobService } from '../../job.service';
import { CenterList } from 'src/app/models/center-list.model';

@Component({
  selector: 'app-getcenter',
  templateUrl: './getcenter.component.html',
  styleUrls: ['./getcenter.component.css']
})
export class GetcenterComponent implements OnInit {
center : CenterList[];

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }
ngOnInit() {

    


 let categoryId = window.localStorage.getItem("categoryId");
  alert(categoryId);
     this.jobService.getCenter1(+categoryId)
      .subscribe( data => {
      
        this.center = data.result ;
    console.log( this.center);
       
      });

  }

 editQuestion(q:CenterList): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
     this.router.navigate(['job/center-update']);
   alert(q.id.toString());
  };

  addCenter(): void {
   this.router.navigate(['job/center']);
  }; 

  sendto(q:CenterList): void {
  window.localStorage.removeItem("centerId");
  window.localStorage.setItem("centerId", q.id.toString());
   this.router.navigate(['job/gettest']);
  }; 


   sendtostatus(q:CenterList): void {
  window.localStorage.removeItem("centerId");
  window.localStorage.setItem("centerId", q.id.toString());



  
    alert( q.id.toString());
     this.jobService.centerStatus(+q.id.toString())
      .subscribe( data => {
      
        this.center = data.result ;
    console.log( this.center);
         
      });



  }; 

}

