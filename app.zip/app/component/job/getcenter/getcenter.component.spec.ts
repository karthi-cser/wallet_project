import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetcenterComponent } from './getcenter.component';

describe('GetcenterComponent', () => {
  let component: GetcenterComponent;
  let fixture: ComponentFixture<GetcenterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetcenterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetcenterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
