import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";
import { JobService } from '../../job.service';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

  addForm: FormGroup;

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      id: [],
      c_name: ['', Validators.required], 
      description: ['', Validators.required]
     
    });

  }

  onSubmit() {
    this.jobService.createCategory(this.addForm.value)
      .subscribe( data => {
        this.router.navigate(['category-list']);
      });
  }

}
