import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetquestionComponent } from './getquestion.component';

describe('GetquestionComponent', () => {
  let component: GetquestionComponent;
  let fixture: ComponentFixture<GetquestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetquestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetquestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
