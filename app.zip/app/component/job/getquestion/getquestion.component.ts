import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";

import {FormBuilder, FormGroup, Validators} from "@angular/forms";


import { JobService } from '../../job.service';
import { Question } from 'src/app/models/question.model';



@Component({
  selector: 'app-getquestion',
  templateUrl: './getquestion.component.html',
  styleUrls: ['./getquestion.component.css']
})
export class GetquestionComponent implements OnInit {
questions : Question[];

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

   ngOnInit() {
	
 let testId = window.localStorage.getItem("testId");
  alert(testId);
     this.jobService.getQuestion1(+testId)
      .subscribe( data => {
      alert(testId);
        this.questions = data.result ;
    console.log( this.questions);
       
      });
  }

   editQuestion(q: Question): void {
    window.localStorage.removeItem("editQuestionId");
    window.localStorage.setItem("editQuestionId", q.id.toString());
     this.router.navigate(['job/question/updatequestion']);
   alert(q.id.toString());
  };
  

}
