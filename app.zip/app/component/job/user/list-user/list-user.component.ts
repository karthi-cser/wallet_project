import { Component, OnInit , Inject} from '@angular/core';
import {Router} from "@angular/router";

import { JobService } from '../../../job.service';
 import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-list-user',
  templateUrl: './list-user.component.html',
  styleUrls: ['./list-user.component.css']
})
export class ListUserComponent implements OnInit {

  users: User[];

  constructor(private router: Router, private jobService: JobService) { }

  ngOnInit() {

    if(!window.localStorage.getItem('token')) {
      this.router.navigate(['login']);
      return;
    }
    let token = localStorage.getItem('token');
  alert(token);
  
    this.jobService.getUsers1()
      .subscribe( data => {
        this.users = data.result;
      });
  }

  deleteUser(user: User): void {
    this.jobService.deleteUser(user.id)
      .subscribe( data => {
        this.users = this.users.filter(u => u !== user);
      })
  };

  editUser(user: User): void {
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());
    this.router.navigate(['job/user/edit-user']);
  };

  addUser(): void {
    this.router.navigate(['job/user/add-user']);
  }; 


sendtostatus(user:User): void {
 
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());

  
    alert(user.id.toString());
     this.jobService.studentStatus(+user.id.toString())
      .subscribe( data => {
      
        this.users = data.result ;
    console.log( this.users);
    this.jobService.getUsers1()
      .subscribe( data => {
        this.users = data.result;
      });

         
      });



  }; 
 
}
