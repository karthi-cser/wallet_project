import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup, Validators} from "@angular/forms";
import {Router} from "@angular/router";

import { JobService } from '../../../job.service';


@Component({
  selector: 'app-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.css']
})
export class AddUserComponent implements OnInit {

  constructor(private formBuilder: FormBuilder,private router: Router, private jobService: JobService) { }

  addForm: FormGroup;

  ngOnInit() {
    this.addForm = this.formBuilder.group({
      id: [],
      name: ['', Validators.required],
      mobile_no: ['', Validators.required],
      father_name: ['', Validators.required],
      father_mobile_no: ['', Validators.required],
     
    });

  }

  student_details(){
  this.router.navigate(['job/student']);
  }

  onSubmit() {
    this.jobService.createUser(this.addForm.value)
      .subscribe( data => {
      alert("Student added successfully");
        this.router.navigate(['job/user/list-user']);
      });
  }

}
