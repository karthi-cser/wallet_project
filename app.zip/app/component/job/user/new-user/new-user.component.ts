import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";

import { JobService } from '../../../job.service';
 import { User } from 'src/app/models/user.model';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.css']
})
export class NewUserComponent implements OnInit {
users: User[];


  constructor(private router: Router, private jobService: JobService) { }

  ngOnInit() {

  if(!window.localStorage.getItem('token')) {
      this.router.navigate(['login']);
      return;
    }
    let token = localStorage.getItem('token');
  alert(token);
  
    this.jobService.getnewUsers()
      .subscribe( data => {
        this.users = data.result;
      });
  }


  sendtostatus(user:User): void {
 
    window.localStorage.removeItem("editUserId");
    window.localStorage.setItem("editUserId", user.id.toString());

  
    alert(user.id.toString());
     this.jobService.newstudentStatus(+user.id.toString())
      .subscribe( data => {
      
        this.users = data.result ;
    console.log( this.users);
    this.router.navigate(['job/user/list-user']);
    this.jobService.getnewUsers()
      .subscribe( data => {
        this.users = data.result;
      });

         
      });



  }; 

}
